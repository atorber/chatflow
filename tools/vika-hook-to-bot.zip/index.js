const { BotController } = require('easy-chatbot-controller')

exports.handler = async (event, context, callback) => {
    console.debug(event.body)
    console.debug(event.body)
    let body = JSON.parse(event.body)

    if (body.toId && body.msg) {
        const iotcoreid = ''
        const username = ''
        const password = ''
        const botId = ''

        const bcr = new BotController(iotcoreid, username, password, botId)
        let res = await bcr.sendText([body.toId,], body.msg)
        // let res = await bcr.sendText(['tyutluyc',], 'hello from cfc')
        callback(null, res);
    }
    callback(null, "参数错误");
};