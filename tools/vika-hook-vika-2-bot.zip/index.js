const { BotController } = require('easy-chatbot-controller')

exports.handler = async (event, context, callback) => {
    console.debug(event.body)
    console.debug(event.body)
    let body = JSON.parse(event.body)

    if (body.toId && body.msg) {
        const iotcoreid = ''
        const username = ''
        const password = ''
        const botId = ''
        let res = ''
        const bcr = new BotController(iotcoreid, username, password, botId)
        if(body.action === 'command'){
            res = await bcr.pubMsgByName(body.name, body.params)
        }else if (body.toId) {
            res = await bcr.sendText([body.toId,], body.msg)
        } else {
            res = '参数错误'
        }
        // let res = await bcr.sendText(['tyutluyc',], 'hello from cfc')
        callback(null, res);
    }
    callback(null, "参数错误");
};